#include "Phone.h"
using namespace std;


Phone::Phone(){
    areaCode = 0;
    number = 0;

}
Phone::Phone( const int areaCode, const int number ){
    this->areaCode = areaCode;
    this->number = number;


 }
int Phone::getAreaCode(){
    return areaCode;

 }
 void Phone::setAreaCode(int areaCode){
     this->areaCode = areaCode;
 }
  void Phone::setNumber(int number){
     this->number = number;
 }
int Phone::getNumber(){
    return number;
 }

 int areaCode;
 int number;



