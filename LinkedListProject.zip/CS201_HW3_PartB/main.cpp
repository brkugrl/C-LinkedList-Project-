#include "Phone.h"
#include "Person.h"
#include "PhoneBook.h"
#include <iostream>

using namespace std;

int main()
{
    PhoneBook* p = new PhoneBook();
    p->addPerson("George");
    p->addPerson("Michael");
    p->addPerson("Berke");

    p->removePerson("John");
    p->displayPeople();
    p->addPhone("George",12,34);
    p->addPhone("George",12,35);
    p->displayPeople();

    p->removePhone("George",12,34);
    p->displayPeople();

    p->removePhone("berke",12,12);
    p->removePhone("Michael",12,36);
    p->displayPeople();

    return 0;
}




