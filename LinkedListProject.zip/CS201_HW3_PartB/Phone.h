#ifndef __PHONE_H
#define __PHONE_H
using namespace std;
class Phone{
public:
Phone();
 Phone( const int areaCode, const int number );
 int getAreaCode();
 int getNumber();
 void setAreaCode(const int areaCode);
 void setNumber(const int number);
private:
 int areaCode;
 int number;
};
#endif
