#include "Phone.h"
#include "Person.h"
#include <iostream>

using namespace std;
#include <string>

Person::Person(const string name){

    numberOfPhones = 0;
    head = NULL;
}

 Person::~Person(){
     while(numberOfPhones != 0){
        if(numberOfPhones == 1){
            head->next = NULL;
            delete head;
            numberOfPhones--;
        }
        else{
            PhoneNode* cur = head;
            head = head->next;
            cur->next = NULL;
            delete cur;
            numberOfPhones--;

        }
     }
 }
 Person::Person( const Person& personToCopy ){
     if( personToCopy.head == NULL)
        this->Person::~Person();

     else{
        this->Person::~Person();
        PhoneNode* cur = personToCopy.head;
        for(int i = 0; i < personToCopy.numberOfPhones; i++){
            addPhone((cur->p).getAreaCode(),(cur->p).getNumber());
            cur = cur->next;
        }

     }
 }
 void Person::operator=( const Person &right ){
     if( right.head == NULL)
        this->Person::~Person();

     else{
        this->Person::~Person();
        PhoneNode* cur = right.head;
        for(int i = 0; i < right.numberOfPhones; i++){
            addPhone((cur->p).getAreaCode(),(cur->p).getNumber());
            cur = cur->next;
        }

     }
 }

 string Person::getName(){
     return (this->name);
 }



void Person::setHead(){
    head = NULL;
}

void Person::setNumberOfPhones(){
    numberOfPhones = 0;
}


 bool Person::addPhone( const int areaCode, const int number ){
     //cout<<"control"<<endl;
     if(findPhone(areaCode,number) != NULL){
        return false;
     }

     PhoneNode* phnNode = new PhoneNode;
     phnNode->next = NULL;

     (phnNode->p).setAreaCode(areaCode);
     (phnNode->p).setNumber(number);
     //cout<<(phnNode->p).getNumber()<<endl;
     //cout<<(phnNode->p).getAreaCode()<<endl;

     if(numberOfPhones == 0){
            head = phnNode;
            head->next = NULL;

     }
     else{
            PhoneNode* phn = head;
            while(phn->next != NULL){
                phn = phn->next;
            }
            phn->next = phnNode;
            //phn->next = NULL;
            //delete phn;

     }
     numberOfPhones++;
     return true;

 }


 bool Person::removePhone( const int areaCode, const int number ){
     if((numberOfPhones == 0) || (findPhone(areaCode,number) == NULL)){
        //cout<<"phone cant found"<<endl;
        return false;
     }

     PhoneNode* temp = findPhone(areaCode,number);

     if(temp == head){


        if(temp->next != NULL){
            head = head->next;
            numberOfPhones--;
            temp->next = NULL;
            delete temp;
            return true;
        }
        else{

            head->next = NULL;
            delete head;
            numberOfPhones--;
            return true;
        }
     }
     else{

        PhoneNode* ctr = this->head;
        while(ctr->next != temp){
            ctr = ctr->next;
        }

        ctr->next = ctr->next->next;
     }
     temp->next = NULL;
     delete temp;
     numberOfPhones--;
     return true;


 }
 void Person::displayPhoneNumbers(){
     PhoneNode* cur = head;
     if((cur == NULL) || (numberOfPhones == 0) ){
        cout<<"--EMPTY--"<<endl;
     }
     else{
        while(cur != NULL){
            cout<<"Phone Number: "<<(cur->p).getAreaCode()<<", " ;
            cout<<(cur->p).getNumber()<<endl;
            cur = cur->next;
        }
     }
 }

 void Person::setName(const string name){
    this->name = name;
 }
  int Person::getNumberOfPhones(){
    return numberOfPhones;
 }
/*Person::PhoneNode* Person::returnHead(){
    return head;
}*/

 struct PhoneNode {
 Phone p;
 PhoneNode* next;
 };

 PhoneNode *head;
 string name;
 int numberOfPhones;

Person::PhoneNode* Person::findPhone(int areaCode,int number ){

     Phone p = Phone(areaCode,number);
     PhoneNode* cur = head;
     PhoneNode* temp = NULL;
     for(int i = 0; i < numberOfPhones; i++){
        if((cur->p.getAreaCode() == p.getAreaCode()) && (cur->p.getNumber() == p.getNumber())){
            temp = cur;
        }
        cur = cur->next;
     }
     return temp;

 }



