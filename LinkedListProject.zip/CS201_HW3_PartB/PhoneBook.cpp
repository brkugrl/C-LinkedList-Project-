#include <iostream>
#include <string>
using namespace std;
#include "Person.h"
#include "PhoneBook.h"


PhoneBook::PhoneBook(){
    headP = NULL;
    numberOfPeople = 0;
 }
 PhoneBook::~PhoneBook(){
 }
 PhoneBook::PhoneBook( const PhoneBook& systemToCopy ){
 }
 void PhoneBook::operator=( const PhoneBook &right ){
 }

 bool PhoneBook::addPerson( string name ){
     if(findPerson(name) != NULL){
        cout<<"person already exist"<<endl;
        return false;
     }

     Node* node = new Node;


     string name2 = toUpperCase(name);
     (node->t).setName(name2);
     (node->t).setHead();
     (node->t).setNumberOfPhones();

     node->next = NULL;

     if(numberOfPeople == 0){

        headP = node;
        headP->next = NULL;
        numberOfPeople++;

        return true;
     }
     else{

        Node* cur = headP;
        while(cur->next != NULL){
            cur = cur->next;

        }
        cur->next = node;
        numberOfPeople++;
        return true;

     }
 }

 bool PhoneBook::removePerson( string name ){
     if(findPerson(name) == NULL || numberOfPeople == 0){
        cout<<"person cant be found"<<endl;
        return false;
     }
     Node* cur = findPerson(name);
     if(cur == headP){
        if(headP->next != NULL){
            headP = headP->next;
            cur->next = NULL;
            delete cur;
            numberOfPeople--;
            return true;
        }
        else{
            headP->next = NULL;
            delete headP;
            numberOfPeople--;
            return true;
        }
     }
     Node* temp = headP;
     while(temp->next != cur){
        temp = temp->next;
     }
     Node* temp2 = temp->next;
     //temp = temp->next;
     temp->next = temp2->next;
     temp2->next = NULL;
     delete temp2;
     numberOfPeople--;
     return true;

 }
 bool PhoneBook::addPhone( string personName, int areaCode, int number ){
     if((numberOfPeople == 0) || (findPerson(personName) == NULL)){
        cout<<"Person cant found,so phone didn't added"<<endl;
        return false;
     }
     else{
        Node* cur = findPerson(personName);
        cur->t.addPhone(areaCode,number);
     }

 }


 bool PhoneBook::removePhone( string personName, int areaCode, int number ){
     if((numberOfPeople == 0) || (findPerson(personName) == NULL)){
        cout<<"Person cant found,so phone didn't removed"<<endl;
        return false;
     }

     Node* cur = findPerson(personName);
     if(cur->t.removePhone(areaCode,number)){
        return true;
     }
     cout<<"Person found but phone cant found"<<endl;
     return false;
 }



 void PhoneBook::displayPerson( string name ){
     Node* cur = findPerson(name);
     if(cur == NULL){
        cout<<"--EMPTY--"<<endl;
     }
     else{
        cout<<cur->t.getName()<<endl;
        cur->t.displayPhoneNumbers();
     }
 }



 void PhoneBook::displayAreaCode( int areaCode ){
     Node* cur = headP;
     cout<<areaCode<<endl;

     /*while(cur != NULL){
        while(cur->t.head != NULL){
            if(cur->t->p.getAreaCode() == areaCode){
                //displayPerson()
            }
            cur->t->head = cur->t->head->next;
        }
        cur = cur->next;
     }*/
 }




 void PhoneBook::displayPeople(){
     Node* cur = headP;
     if((cur == NULL) || (numberOfPeople == 0)){
            cout<<"--EMPTY--"<<endl;
     }
     else{
       while(cur != NULL){
            cout<<"Person "<< (cur->t).getName()<<", ";
            cout<<"number of phones ";
            cout<<(cur->t).getName()<<" ";
            cout<<"has "<<(cur->t).getNumberOfPhones()<<endl;
            cur = cur->next;
     }
    }
 }
 string PhoneBook::toUpperCase(string str){

     string name2 = str;
     for(int x = 1; x <= name2.length()+1; x++)
     {
	    if((name2[x-1] <= 122) && (name2[x-1] >= 97))
	    {
            name2[x-1] = -32 + name2[x-1];
	    }
     }
     return name2;

 }


 struct Node {
 Person t;
 Node* next;
 };

 Node *headP;
 int numberOfPeople;


 PhoneBook::Node* PhoneBook::findPerson( string name ){

     string name2 = toUpperCase(name);
     Node* cur = headP;
     Node* temp = NULL;
     if((cur == NULL) || (numberOfPeople == 0))
        return NULL;
     while(cur != NULL){
        if(cur->t.getName() == name2){
            temp = cur;
        }
        cur = cur->next;
     }

     return temp;

 }


